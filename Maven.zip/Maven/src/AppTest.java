import org.junit.Test;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

public class AppTest {
	@Test
	
	public void ploan() {
		
		System.out.println("good");


}
@BeforeTest

public void prerequiste() {
	
	System.out.println("goodwer");
	
	
}



@AfterTest

public void prerequiste1() {
	
	System.out.println("5646");
	
	
}
}
